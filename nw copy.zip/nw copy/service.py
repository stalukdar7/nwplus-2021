import requests

import json

data = json.loads(requests.get("https://eonet.sci.gsfc.nasa.gov/api/v2.1/events").text)
 

def func(lat, lon, eventId, rad, time):
    ans = []
    for event in data ['events']:
        for category in event ['categories']:
            if category ['id'] == int (eventId): 
                ans.append ([event ['title']])  
            else:
                pass
    return ans 

if __name__ == "__main__":
    func (1, 2, 8, 7, 8)


    

    












    









        
        





    
       
