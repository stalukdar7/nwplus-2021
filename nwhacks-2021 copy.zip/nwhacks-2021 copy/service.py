import requests

import json

data = json.loads(requests.get("https://eonet.sci.gsfc.nasa.gov/api/v2.1/events").text)
 

ans = []

def func(lat, lon, eventId, rad, time):
    for event in data ['events']:
        for category in event ['categories']:
            if category ['id'] == int (eventId): 
                ans.append ([event ['title']])  
            else:
                pass
    return ans

print (func (2, 3, 12, 5, 6))









    









        
        





    
       
